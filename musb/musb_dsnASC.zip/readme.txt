Readme Notes for Morse USB-HID Interface
Feb 22, 2020

These files are PCAD ASCII exports from Protel99 SE.  I have no way to validate them other than re-importing into Protel (which has not been done).
Thus, these files may not be useable.  Please report problems to me at joeh@rollanet.org.

Cheers,

Joe Haas
KE0FF
